# Online Python compiler (interpreter)
# Write and run Python online using this editor.

import random

# List of 5 predefined words
words = ["python", "laptop", "coding", "puzzle", "network"]

MAX_WRONG = 6

# Pick a random word
word = random.choice(words)

guessed_letters = []   # all letters the player has tried
wrong_guesses = 0

print("=== HANGMAN ===")
print("Guess the word one letter at a time. You get", MAX_WRONG, "wrong guesses.\n")

while wrong_guesses < MAX_WRONG:
    # Build the display string, e.g. "p _ t h _ n"
    display = ""
    for letter in word:
        if letter in guessed_letters:
            display += letter + " "
        else:
            display += "_ "
    print("Word:", display)
    print("Guessed:", " ".join(guessed_letters))
    print("Wrong guesses left:", MAX_WRONG - wrong_guesses)

    # Check for win
    if "_" not in display:
        print("\nYou won! The word was '" + word + "'.")
        break

    guess = input("\nEnter a letter: ").lower().strip()

    # Validate input
    if len(guess) != 1 or not guess.isalpha():
        print("Please enter a single letter.\n")
    elif guess in guessed_letters:
        print("You already guessed that letter.\n")
    else:
        guessed_letters.append(guess)
        if guess in word:
            print("Good guess!\n")
        else:
            wrong_guesses += 1
            print("Wrong guess!\n")
else:
    # Runs only if the loop ended without 'break' (i.e. the player lost)
    print("Game over! The word was '" + word + "'.")
